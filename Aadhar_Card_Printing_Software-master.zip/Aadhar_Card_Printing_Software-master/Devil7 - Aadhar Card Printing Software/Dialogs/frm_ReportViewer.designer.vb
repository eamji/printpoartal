﻿
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
    Partial Class frm_ReportViewer
        Inherits DevExpress.XtraBars.Ribbon.RibbonForm

        'Form overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()>
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()>
        Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim SuperToolTip1 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem1 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem1 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip2 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem2 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem2 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip3 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem3 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem3 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip4 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem4 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem4 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip5 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem5 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem5 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip6 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem6 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem6 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip7 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem7 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem7 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip8 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem8 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem8 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip9 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem9 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem9 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip10 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem10 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem10 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip11 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem11 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem11 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip12 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem12 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem12 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip13 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem13 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem13 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip14 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem14 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem14 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip15 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem15 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem15 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip16 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem16 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem16 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip17 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem17 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem17 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip18 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem18 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem18 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip19 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem19 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem19 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip20 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem20 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem20 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip21 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem21 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem21 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip22 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem22 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem22 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip23 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem23 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem23 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip24 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem24 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem24 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip25 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem25 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem25 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip26 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem26 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem26 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip27 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem27 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem27 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip28 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem28 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem28 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip29 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem29 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem29 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip30 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem30 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem30 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip31 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem31 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem31 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip32 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem32 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem32 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip33 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem33 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem33 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip34 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem34 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem34 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip35 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem35 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem35 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip36 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem36 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem36 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip37 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem37 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem37 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip38 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem38 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem38 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip39 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem39 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem39 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip40 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem40 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem40 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip41 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem41 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem41 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip42 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem42 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem42 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip43 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem43 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem43 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip44 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem44 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem44 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip45 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem45 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem45 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip46 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem46 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem46 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip47 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem47 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem47 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip48 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem48 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem48 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip49 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem49 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem49 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_ReportViewer))
        Me.DocumentViewer = New DevExpress.XtraPrinting.Preview.DocumentViewer()
        Me.RibbonController = New DevExpress.XtraPrinting.Preview.DocumentViewerRibbonController(Me.components)
        Me.RibbonControl = New DevExpress.XtraBars.Ribbon.RibbonControl()
        Me.btn_Navigation_EditingFields = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Navigation_Bookmarks = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Navigation_Find = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Navigation_Thumbnails = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Print_Options = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Print = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_QuickPrint = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_PageSetup_Margins_Custom = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_PageSetup_HeaderFooter = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_PageSetup_Scale = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Zoom_Pointer = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Zoom_Hand = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Zoom_MagGlass = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Zoom_Out = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Zoom_In = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Zoom_Zoom = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Navigation_First = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Navigation_Previous = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Navigation_Next = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Navigation_Last = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Zoom_MultiplePages = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_PageSetup_PageColor = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_PageSetup_Watermark = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_Mail = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Close = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_PageSetup_Orientation = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_PageSetup_Size = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_PageSetup_Margins = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Send_PDF = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Send_Text = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Send_CSV = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Send_Mht = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Send_Xls = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Send_Xlsx = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Send_RTF = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Send_Docx = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Send_Image = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_PDF = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_HTML = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_Text = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_CSV = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_Mht = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_Xls = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_Xlsx = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_RTF = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_Docx = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.btn_Export_Image = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.txt_Status = New DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem()
        Me.BarStaticItem1 = New DevExpress.XtraBars.BarStaticItem()
        Me.progress_Status = New DevExpress.XtraPrinting.Preview.ProgressBarEditItem()
        Me.progress_Status_Item = New DevExpress.XtraEditors.Repository.RepositoryItemProgressBar()
        Me.btn_Stop = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.txt_Zoom = New DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem()
        Me.track_Zoom = New DevExpress.XtraPrinting.Preview.ZoomTrackBarEditItem()
        Me.track_Zoom_Item = New DevExpress.XtraEditors.Repository.RepositoryItemZoomTrackBar()
        Me.rp_PrintPreview = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPage()
        Me.rpg_Print = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.rpg_Navigation = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.rpg_Zoom = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.rpg_Export = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.rpg_Close = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.rp_PageSetup = New DevExpress.XtraBars.Ribbon.RibbonPage()
        Me.rpg_PageSetup = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.RibbonStatusBar = New DevExpress.XtraBars.Ribbon.RibbonStatusBar()
        CType(Me.RibbonController, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RibbonControl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.progress_Status_Item, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.track_Zoom_Item, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DocumentViewer
        '
        Me.DocumentViewer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DocumentViewer.IsMetric = True
        Me.DocumentViewer.Location = New System.Drawing.Point(0, 143)
        Me.DocumentViewer.Name = "DocumentViewer"
        Me.DocumentViewer.Size = New System.Drawing.Size(758, 276)
        Me.DocumentViewer.TabIndex = 0
        '
        'RibbonController
        '
        Me.RibbonController.DocumentViewer = Me.DocumentViewer
        Me.RibbonController.RibbonControl = Me.RibbonControl
        Me.RibbonController.RibbonStatusBar = Me.RibbonStatusBar
        '
        'RibbonControl
        '
        Me.RibbonControl.AutoHideEmptyItems = True
        Me.RibbonControl.ExpandCollapseItem.Id = 0
        Me.RibbonControl.Items.AddRange(New DevExpress.XtraBars.BarItem() {Me.RibbonControl.ExpandCollapseItem, Me.btn_Navigation_EditingFields, Me.btn_Navigation_Bookmarks, Me.btn_Navigation_Find, Me.btn_Navigation_Thumbnails, Me.btn_Print_Options, Me.btn_Print, Me.btn_QuickPrint, Me.btn_PageSetup_Margins_Custom, Me.btn_PageSetup_HeaderFooter, Me.btn_PageSetup_Scale, Me.btn_Zoom_Pointer, Me.btn_Zoom_Hand, Me.btn_Zoom_MagGlass, Me.btn_Zoom_Out, Me.btn_Zoom_In, Me.btn_Zoom_Zoom, Me.btn_Navigation_First, Me.btn_Navigation_Previous, Me.btn_Navigation_Next, Me.btn_Navigation_Last, Me.btn_Zoom_MultiplePages, Me.btn_PageSetup_PageColor, Me.btn_PageSetup_Watermark, Me.btn_Export, Me.btn_Export_Mail, Me.btn_Close, Me.btn_PageSetup_Orientation, Me.btn_PageSetup_Size, Me.btn_PageSetup_Margins, Me.btn_Send_PDF, Me.btn_Send_Text, Me.btn_Send_CSV, Me.btn_Send_Mht, Me.btn_Send_Xls, Me.btn_Send_Xlsx, Me.btn_Send_RTF, Me.btn_Send_Docx, Me.btn_Send_Image, Me.btn_Export_PDF, Me.btn_Export_HTML, Me.btn_Export_Text, Me.btn_Export_CSV, Me.btn_Export_Mht, Me.btn_Export_Xls, Me.btn_Export_Xlsx, Me.btn_Export_RTF, Me.btn_Export_Docx, Me.btn_Export_Image, Me.txt_Status, Me.BarStaticItem1, Me.progress_Status, Me.btn_Stop, Me.txt_Zoom, Me.track_Zoom})
        Me.RibbonControl.Location = New System.Drawing.Point(0, 0)
        Me.RibbonControl.MaxItemId = 58
        Me.RibbonControl.Name = "RibbonControl"
        Me.RibbonControl.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() {Me.rp_PrintPreview, Me.rp_PageSetup})
        Me.RibbonControl.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.progress_Status_Item, Me.track_Zoom_Item})
        Me.RibbonControl.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.[False]
        Me.RibbonControl.ShowCategoryInCaption = False
        Me.RibbonControl.ShowDisplayOptionsMenuButton = DevExpress.Utils.DefaultBoolean.[False]
        Me.RibbonControl.ShowQatLocationSelector = False
        Me.RibbonControl.ShowToolbarCustomizeItem = False
        Me.RibbonControl.Size = New System.Drawing.Size(758, 143)
        Me.RibbonControl.StatusBar = Me.RibbonStatusBar
        Me.RibbonControl.Toolbar.ShowCustomizeItem = False
        Me.RibbonControl.TransparentEditorsMode = DevExpress.Utils.DefaultBoolean.[True]
        '
        'btn_Navigation_EditingFields
        '
        Me.btn_Navigation_EditingFields.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.btn_Navigation_EditingFields.Caption = "Editing Fields"
        Me.btn_Navigation_EditingFields.Command = DevExpress.XtraPrinting.PrintingSystemCommand.HighlightEditingFields
        Me.btn_Navigation_EditingFields.ContextSpecifier = Me.RibbonController
        Me.btn_Navigation_EditingFields.Enabled = False
        Me.btn_Navigation_EditingFields.Id = 1
        Me.btn_Navigation_EditingFields.Name = "btn_Navigation_EditingFields"
        Me.btn_Navigation_EditingFields.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        SuperToolTip1.FixedTooltipWidth = True
        ToolTipTitleItem1.Text = "Highlight Editing Fields"
        ToolTipItem1.LeftIndent = 6
        ToolTipItem1.Text = "Highlight all editing fields to quickly discover which of the document elements a" &
    "re editable."
        SuperToolTip1.Items.Add(ToolTipTitleItem1)
        SuperToolTip1.Items.Add(ToolTipItem1)
        SuperToolTip1.MaxWidth = 210
        Me.btn_Navigation_EditingFields.SuperTip = SuperToolTip1
        '
        'btn_Navigation_Bookmarks
        '
        Me.btn_Navigation_Bookmarks.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.btn_Navigation_Bookmarks.Caption = "Bookmarks"
        Me.btn_Navigation_Bookmarks.Command = DevExpress.XtraPrinting.PrintingSystemCommand.DocumentMap
        Me.btn_Navigation_Bookmarks.ContextSpecifier = Me.RibbonController
        Me.btn_Navigation_Bookmarks.Enabled = False
        Me.btn_Navigation_Bookmarks.Id = 2
        Me.btn_Navigation_Bookmarks.Name = "btn_Navigation_Bookmarks"
        Me.btn_Navigation_Bookmarks.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        SuperToolTip2.FixedTooltipWidth = True
        ToolTipTitleItem2.Text = "Document Map"
        ToolTipItem2.LeftIndent = 6
        ToolTipItem2.Text = "Open the Document Map, which allows you to navigate through a structural view of " &
    "the document."
        SuperToolTip2.Items.Add(ToolTipTitleItem2)
        SuperToolTip2.Items.Add(ToolTipItem2)
        SuperToolTip2.MaxWidth = 210
        Me.btn_Navigation_Bookmarks.SuperTip = SuperToolTip2
        '
        'btn_Navigation_Find
        '
        Me.btn_Navigation_Find.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.btn_Navigation_Find.Caption = "Find"
        Me.btn_Navigation_Find.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Find
        Me.btn_Navigation_Find.ContextSpecifier = Me.RibbonController
        Me.btn_Navigation_Find.Enabled = False
        Me.btn_Navigation_Find.Id = 4
        Me.btn_Navigation_Find.Name = "btn_Navigation_Find"
        Me.btn_Navigation_Find.RibbonStyle = CType((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large Or DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText), DevExpress.XtraBars.Ribbon.RibbonItemStyles)
        SuperToolTip3.FixedTooltipWidth = True
        ToolTipTitleItem3.Text = "Find"
        ToolTipItem3.LeftIndent = 6
        ToolTipItem3.Text = "Show the Find dialog to find text in the document."
        SuperToolTip3.Items.Add(ToolTipTitleItem3)
        SuperToolTip3.Items.Add(ToolTipItem3)
        SuperToolTip3.MaxWidth = 210
        Me.btn_Navigation_Find.SuperTip = SuperToolTip3
        '
        'btn_Navigation_Thumbnails
        '
        Me.btn_Navigation_Thumbnails.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.btn_Navigation_Thumbnails.Caption = "Thumbnails"
        Me.btn_Navigation_Thumbnails.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Thumbnails
        Me.btn_Navigation_Thumbnails.ContextSpecifier = Me.RibbonController
        Me.btn_Navigation_Thumbnails.Enabled = False
        Me.btn_Navigation_Thumbnails.Id = 5
        Me.btn_Navigation_Thumbnails.Name = "btn_Navigation_Thumbnails"
        Me.btn_Navigation_Thumbnails.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        SuperToolTip4.FixedTooltipWidth = True
        ToolTipTitleItem4.Text = "Thumbnails"
        ToolTipItem4.LeftIndent = 6
        ToolTipItem4.Text = "Open the Thumbnails, which allows you to navigate through the document."
        SuperToolTip4.Items.Add(ToolTipTitleItem4)
        SuperToolTip4.Items.Add(ToolTipItem4)
        SuperToolTip4.MaxWidth = 210
        Me.btn_Navigation_Thumbnails.SuperTip = SuperToolTip4
        '
        'btn_Print_Options
        '
        Me.btn_Print_Options.Caption = "Options"
        Me.btn_Print_Options.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Customize
        Me.btn_Print_Options.ContextSpecifier = Me.RibbonController
        Me.btn_Print_Options.Enabled = False
        Me.btn_Print_Options.Id = 6
        Me.btn_Print_Options.Name = "btn_Print_Options"
        SuperToolTip5.FixedTooltipWidth = True
        ToolTipTitleItem5.Text = "Options"
        ToolTipItem5.LeftIndent = 6
        ToolTipItem5.Text = "Open the Print Options dialog, in which you can change printing options."
        SuperToolTip5.Items.Add(ToolTipTitleItem5)
        SuperToolTip5.Items.Add(ToolTipItem5)
        SuperToolTip5.MaxWidth = 210
        Me.btn_Print_Options.SuperTip = SuperToolTip5
        '
        'btn_Print
        '
        Me.btn_Print.Caption = "Print"
        Me.btn_Print.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Print
        Me.btn_Print.ContextSpecifier = Me.RibbonController
        Me.btn_Print.Enabled = False
        Me.btn_Print.Id = 7
        Me.btn_Print.Name = "btn_Print"
        SuperToolTip6.FixedTooltipWidth = True
        ToolTipTitleItem6.Text = "Print (Ctrl+P)"
        ToolTipItem6.LeftIndent = 6
        ToolTipItem6.Text = "Select a printer, number of copies and other printing options before printing."
        SuperToolTip6.Items.Add(ToolTipTitleItem6)
        SuperToolTip6.Items.Add(ToolTipItem6)
        SuperToolTip6.MaxWidth = 210
        Me.btn_Print.SuperTip = SuperToolTip6
        '
        'btn_QuickPrint
        '
        Me.btn_QuickPrint.Caption = "Quick Print"
        Me.btn_QuickPrint.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PrintDirect
        Me.btn_QuickPrint.ContextSpecifier = Me.RibbonController
        Me.btn_QuickPrint.Enabled = False
        Me.btn_QuickPrint.Id = 8
        Me.btn_QuickPrint.Name = "btn_QuickPrint"
        SuperToolTip7.FixedTooltipWidth = True
        ToolTipTitleItem7.Text = "Quick Print"
        ToolTipItem7.LeftIndent = 6
        ToolTipItem7.Text = "Send the document directly to the default printer without making changes."
        SuperToolTip7.Items.Add(ToolTipTitleItem7)
        SuperToolTip7.Items.Add(ToolTipItem7)
        SuperToolTip7.MaxWidth = 210
        Me.btn_QuickPrint.SuperTip = SuperToolTip7
        '
        'btn_PageSetup_Margins_Custom
        '
        Me.btn_PageSetup_Margins_Custom.Caption = "Custom Margins..."
        Me.btn_PageSetup_Margins_Custom.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageSetup
        Me.btn_PageSetup_Margins_Custom.ContextSpecifier = Me.RibbonController
        Me.btn_PageSetup_Margins_Custom.Enabled = False
        Me.btn_PageSetup_Margins_Custom.Id = 9
        Me.btn_PageSetup_Margins_Custom.Name = "btn_PageSetup_Margins_Custom"
        SuperToolTip8.FixedTooltipWidth = True
        ToolTipTitleItem8.Text = "Page Setup"
        ToolTipItem8.LeftIndent = 6
        ToolTipItem8.Text = "Show the Page Setup dialog."
        SuperToolTip8.Items.Add(ToolTipTitleItem8)
        SuperToolTip8.Items.Add(ToolTipItem8)
        SuperToolTip8.MaxWidth = 210
        Me.btn_PageSetup_Margins_Custom.SuperTip = SuperToolTip8
        '
        'btn_PageSetup_HeaderFooter
        '
        Me.btn_PageSetup_HeaderFooter.Caption = "Header/Footer"
        Me.btn_PageSetup_HeaderFooter.Command = DevExpress.XtraPrinting.PrintingSystemCommand.EditPageHF
        Me.btn_PageSetup_HeaderFooter.ContextSpecifier = Me.RibbonController
        Me.btn_PageSetup_HeaderFooter.Enabled = False
        Me.btn_PageSetup_HeaderFooter.Id = 10
        Me.btn_PageSetup_HeaderFooter.Name = "btn_PageSetup_HeaderFooter"
        SuperToolTip9.FixedTooltipWidth = True
        ToolTipTitleItem9.Text = "Header and Footer"
        ToolTipItem9.LeftIndent = 6
        ToolTipItem9.Text = "Edit the header and footer of the document."
        SuperToolTip9.Items.Add(ToolTipTitleItem9)
        SuperToolTip9.Items.Add(ToolTipItem9)
        SuperToolTip9.MaxWidth = 210
        Me.btn_PageSetup_HeaderFooter.SuperTip = SuperToolTip9
        '
        'btn_PageSetup_Scale
        '
        Me.btn_PageSetup_Scale.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.btn_PageSetup_Scale.Caption = "Scale"
        Me.btn_PageSetup_Scale.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Scale
        Me.btn_PageSetup_Scale.ContextSpecifier = Me.RibbonController
        Me.btn_PageSetup_Scale.Enabled = False
        Me.btn_PageSetup_Scale.Id = 11
        Me.btn_PageSetup_Scale.Name = "btn_PageSetup_Scale"
        SuperToolTip10.FixedTooltipWidth = True
        ToolTipTitleItem10.Text = "Scale"
        ToolTipItem10.LeftIndent = 6
        ToolTipItem10.Text = "Stretch or shrink the printed output to a percentage of its actual size."
        SuperToolTip10.Items.Add(ToolTipTitleItem10)
        SuperToolTip10.Items.Add(ToolTipItem10)
        SuperToolTip10.MaxWidth = 210
        Me.btn_PageSetup_Scale.SuperTip = SuperToolTip10
        '
        'btn_Zoom_Pointer
        '
        Me.btn_Zoom_Pointer.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.btn_Zoom_Pointer.Caption = "Pointer"
        Me.btn_Zoom_Pointer.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Pointer
        Me.btn_Zoom_Pointer.ContextSpecifier = Me.RibbonController
        Me.btn_Zoom_Pointer.Down = True
        Me.btn_Zoom_Pointer.Enabled = False
        Me.btn_Zoom_Pointer.GroupIndex = 1
        Me.btn_Zoom_Pointer.Id = 12
        Me.btn_Zoom_Pointer.Name = "btn_Zoom_Pointer"
        Me.btn_Zoom_Pointer.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        SuperToolTip11.FixedTooltipWidth = True
        ToolTipTitleItem11.Text = "Mouse Pointer"
        ToolTipItem11.LeftIndent = 6
        ToolTipItem11.Text = "Show the mouse pointer."
        SuperToolTip11.Items.Add(ToolTipTitleItem11)
        SuperToolTip11.Items.Add(ToolTipItem11)
        SuperToolTip11.MaxWidth = 210
        Me.btn_Zoom_Pointer.SuperTip = SuperToolTip11
        '
        'btn_Zoom_Hand
        '
        Me.btn_Zoom_Hand.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.btn_Zoom_Hand.Caption = "Hand Tool"
        Me.btn_Zoom_Hand.Command = DevExpress.XtraPrinting.PrintingSystemCommand.HandTool
        Me.btn_Zoom_Hand.ContextSpecifier = Me.RibbonController
        Me.btn_Zoom_Hand.Enabled = False
        Me.btn_Zoom_Hand.GroupIndex = 1
        Me.btn_Zoom_Hand.Id = 13
        Me.btn_Zoom_Hand.Name = "btn_Zoom_Hand"
        Me.btn_Zoom_Hand.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        SuperToolTip12.FixedTooltipWidth = True
        ToolTipTitleItem12.Text = "Hand Tool"
        ToolTipItem12.LeftIndent = 6
        ToolTipItem12.Text = "Invoke the Hand tool to manually scroll through pages."
        SuperToolTip12.Items.Add(ToolTipTitleItem12)
        SuperToolTip12.Items.Add(ToolTipItem12)
        SuperToolTip12.MaxWidth = 210
        Me.btn_Zoom_Hand.SuperTip = SuperToolTip12
        '
        'btn_Zoom_MagGlass
        '
        Me.btn_Zoom_MagGlass.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.btn_Zoom_MagGlass.Caption = "Magnifier"
        Me.btn_Zoom_MagGlass.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Magnifier
        Me.btn_Zoom_MagGlass.ContextSpecifier = Me.RibbonController
        Me.btn_Zoom_MagGlass.Enabled = False
        Me.btn_Zoom_MagGlass.GroupIndex = 1
        Me.btn_Zoom_MagGlass.Id = 14
        Me.btn_Zoom_MagGlass.Name = "btn_Zoom_MagGlass"
        Me.btn_Zoom_MagGlass.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        SuperToolTip13.FixedTooltipWidth = True
        ToolTipTitleItem13.Text = "Magnifier"
        ToolTipItem13.LeftIndent = 6
        ToolTipItem13.Text = "Invoke the Magnifier tool." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Clicking once on a document zooms it so that a sing" &
    "le page becomes entirely visible, while clicking another time zooms it to 100% o" &
    "f the normal size."
        SuperToolTip13.Items.Add(ToolTipTitleItem13)
        SuperToolTip13.Items.Add(ToolTipItem13)
        SuperToolTip13.MaxWidth = 210
        Me.btn_Zoom_MagGlass.SuperTip = SuperToolTip13
        '
        'btn_Zoom_Out
        '
        Me.btn_Zoom_Out.Caption = "Zoom Out"
        Me.btn_Zoom_Out.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ZoomOut
        Me.btn_Zoom_Out.ContextSpecifier = Me.RibbonController
        Me.btn_Zoom_Out.Enabled = False
        Me.btn_Zoom_Out.Id = 15
        Me.btn_Zoom_Out.Name = "btn_Zoom_Out"
        Me.btn_Zoom_Out.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        SuperToolTip14.FixedTooltipWidth = True
        ToolTipTitleItem14.Text = "Zoom Out"
        ToolTipItem14.LeftIndent = 6
        ToolTipItem14.Text = "Zoom out to see more of the page at a reduced size."
        SuperToolTip14.Items.Add(ToolTipTitleItem14)
        SuperToolTip14.Items.Add(ToolTipItem14)
        SuperToolTip14.MaxWidth = 210
        Me.btn_Zoom_Out.SuperTip = SuperToolTip14
        '
        'btn_Zoom_In
        '
        Me.btn_Zoom_In.Caption = "Zoom In"
        Me.btn_Zoom_In.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ZoomIn
        Me.btn_Zoom_In.ContextSpecifier = Me.RibbonController
        Me.btn_Zoom_In.Enabled = False
        Me.btn_Zoom_In.Id = 16
        Me.btn_Zoom_In.Name = "btn_Zoom_In"
        Me.btn_Zoom_In.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        SuperToolTip15.FixedTooltipWidth = True
        ToolTipTitleItem15.Text = "Zoom In"
        ToolTipItem15.LeftIndent = 6
        ToolTipItem15.Text = "Zoom in to get a close-up view of the document."
        SuperToolTip15.Items.Add(ToolTipTitleItem15)
        SuperToolTip15.Items.Add(ToolTipItem15)
        SuperToolTip15.MaxWidth = 210
        Me.btn_Zoom_In.SuperTip = SuperToolTip15
        '
        'btn_Zoom_Zoom
        '
        Me.btn_Zoom_Zoom.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.btn_Zoom_Zoom.Caption = "Zoom"
        Me.btn_Zoom_Zoom.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Zoom
        Me.btn_Zoom_Zoom.ContextSpecifier = Me.RibbonController
        Me.btn_Zoom_Zoom.Enabled = False
        Me.btn_Zoom_Zoom.Id = 17
        Me.btn_Zoom_Zoom.Name = "btn_Zoom_Zoom"
        SuperToolTip16.FixedTooltipWidth = True
        ToolTipTitleItem16.Text = "Zoom"
        ToolTipItem16.LeftIndent = 6
        ToolTipItem16.Text = "Change the zoom level of the document preview."
        SuperToolTip16.Items.Add(ToolTipTitleItem16)
        SuperToolTip16.Items.Add(ToolTipItem16)
        SuperToolTip16.MaxWidth = 210
        Me.btn_Zoom_Zoom.SuperTip = SuperToolTip16
        '
        'btn_Navigation_First
        '
        Me.btn_Navigation_First.Caption = "First Page"
        Me.btn_Navigation_First.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowFirstPage
        Me.btn_Navigation_First.ContextSpecifier = Me.RibbonController
        Me.btn_Navigation_First.Enabled = False
        Me.btn_Navigation_First.Id = 18
        Me.btn_Navigation_First.Name = "btn_Navigation_First"
        Me.btn_Navigation_First.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        SuperToolTip17.FixedTooltipWidth = True
        ToolTipTitleItem17.Text = "First Page (Home)"
        ToolTipItem17.LeftIndent = 6
        ToolTipItem17.Text = "Navigate to the first page of the document."
        SuperToolTip17.Items.Add(ToolTipTitleItem17)
        SuperToolTip17.Items.Add(ToolTipItem17)
        SuperToolTip17.MaxWidth = 210
        Me.btn_Navigation_First.SuperTip = SuperToolTip17
        '
        'btn_Navigation_Previous
        '
        Me.btn_Navigation_Previous.Caption = "Previous Page"
        Me.btn_Navigation_Previous.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowPrevPage
        Me.btn_Navigation_Previous.ContextSpecifier = Me.RibbonController
        Me.btn_Navigation_Previous.Enabled = False
        Me.btn_Navigation_Previous.Id = 19
        Me.btn_Navigation_Previous.Name = "btn_Navigation_Previous"
        Me.btn_Navigation_Previous.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        SuperToolTip18.FixedTooltipWidth = True
        ToolTipTitleItem18.Text = "Previous Page (Left Arrow)"
        ToolTipItem18.LeftIndent = 6
        ToolTipItem18.Text = "Navigate to the previous page of the document."
        SuperToolTip18.Items.Add(ToolTipTitleItem18)
        SuperToolTip18.Items.Add(ToolTipItem18)
        SuperToolTip18.MaxWidth = 210
        Me.btn_Navigation_Previous.SuperTip = SuperToolTip18
        '
        'btn_Navigation_Next
        '
        Me.btn_Navigation_Next.Caption = "Next  Page "
        Me.btn_Navigation_Next.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowNextPage
        Me.btn_Navigation_Next.ContextSpecifier = Me.RibbonController
        Me.btn_Navigation_Next.Enabled = False
        Me.btn_Navigation_Next.Id = 20
        Me.btn_Navigation_Next.Name = "btn_Navigation_Next"
        SuperToolTip19.FixedTooltipWidth = True
        ToolTipTitleItem19.Text = "Next Page (Right Arrow)"
        ToolTipItem19.LeftIndent = 6
        ToolTipItem19.Text = "Navigate to the next page of the document."
        SuperToolTip19.Items.Add(ToolTipTitleItem19)
        SuperToolTip19.Items.Add(ToolTipItem19)
        SuperToolTip19.MaxWidth = 210
        Me.btn_Navigation_Next.SuperTip = SuperToolTip19
        '
        'btn_Navigation_Last
        '
        Me.btn_Navigation_Last.Caption = "Last  Page "
        Me.btn_Navigation_Last.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowLastPage
        Me.btn_Navigation_Last.ContextSpecifier = Me.RibbonController
        Me.btn_Navigation_Last.Enabled = False
        Me.btn_Navigation_Last.Id = 21
        Me.btn_Navigation_Last.Name = "btn_Navigation_Last"
        Me.btn_Navigation_Last.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText
        SuperToolTip20.FixedTooltipWidth = True
        ToolTipTitleItem20.Text = "Last Page (End)"
        ToolTipItem20.LeftIndent = 6
        ToolTipItem20.Text = "Navigate to the last page of the document."
        SuperToolTip20.Items.Add(ToolTipTitleItem20)
        SuperToolTip20.Items.Add(ToolTipItem20)
        SuperToolTip20.MaxWidth = 210
        Me.btn_Navigation_Last.SuperTip = SuperToolTip20
        '
        'btn_Zoom_MultiplePages
        '
        Me.btn_Zoom_MultiplePages.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.btn_Zoom_MultiplePages.Caption = "Many Pages"
        Me.btn_Zoom_MultiplePages.Command = DevExpress.XtraPrinting.PrintingSystemCommand.MultiplePages
        Me.btn_Zoom_MultiplePages.ContextSpecifier = Me.RibbonController
        Me.btn_Zoom_MultiplePages.Enabled = False
        Me.btn_Zoom_MultiplePages.Id = 22
        Me.btn_Zoom_MultiplePages.Name = "btn_Zoom_MultiplePages"
        SuperToolTip21.FixedTooltipWidth = True
        ToolTipTitleItem21.Text = "View Many Pages"
        ToolTipItem21.LeftIndent = 6
        ToolTipItem21.Text = "Choose the page layout to arrange the document pages in preview."
        SuperToolTip21.Items.Add(ToolTipTitleItem21)
        SuperToolTip21.Items.Add(ToolTipItem21)
        SuperToolTip21.MaxWidth = 210
        Me.btn_Zoom_MultiplePages.SuperTip = SuperToolTip21
        '
        'btn_PageSetup_PageColor
        '
        Me.btn_PageSetup_PageColor.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.btn_PageSetup_PageColor.Caption = "Page Color"
        Me.btn_PageSetup_PageColor.Command = DevExpress.XtraPrinting.PrintingSystemCommand.FillBackground
        Me.btn_PageSetup_PageColor.ContextSpecifier = Me.RibbonController
        Me.btn_PageSetup_PageColor.Enabled = False
        Me.btn_PageSetup_PageColor.Id = 23
        Me.btn_PageSetup_PageColor.Name = "btn_PageSetup_PageColor"
        SuperToolTip22.FixedTooltipWidth = True
        ToolTipTitleItem22.Text = "Background Color"
        ToolTipItem22.LeftIndent = 6
        ToolTipItem22.Text = "Choose a color for the background of the document pages."
        SuperToolTip22.Items.Add(ToolTipTitleItem22)
        SuperToolTip22.Items.Add(ToolTipItem22)
        SuperToolTip22.MaxWidth = 210
        Me.btn_PageSetup_PageColor.SuperTip = SuperToolTip22
        '
        'btn_PageSetup_Watermark
        '
        Me.btn_PageSetup_Watermark.Caption = "Watermark"
        Me.btn_PageSetup_Watermark.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Watermark
        Me.btn_PageSetup_Watermark.ContextSpecifier = Me.RibbonController
        Me.btn_PageSetup_Watermark.Enabled = False
        Me.btn_PageSetup_Watermark.Id = 24
        Me.btn_PageSetup_Watermark.Name = "btn_PageSetup_Watermark"
        SuperToolTip23.FixedTooltipWidth = True
        ToolTipTitleItem23.Text = "Watermark"
        ToolTipItem23.LeftIndent = 6
        ToolTipItem23.Text = "Insert ghosted text or image behind the content of a page." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "This is often used " &
    "to indicate that a document is to be treated specially."
        SuperToolTip23.Items.Add(ToolTipTitleItem23)
        SuperToolTip23.Items.Add(ToolTipItem23)
        SuperToolTip23.MaxWidth = 210
        Me.btn_PageSetup_Watermark.SuperTip = SuperToolTip23
        '
        'btn_Export
        '
        Me.btn_Export.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.btn_Export.Caption = "Export To"
        Me.btn_Export.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportFile
        Me.btn_Export.ContextSpecifier = Me.RibbonController
        Me.btn_Export.Enabled = False
        Me.btn_Export.Id = 25
        Me.btn_Export.Name = "btn_Export"
        SuperToolTip24.FixedTooltipWidth = True
        ToolTipTitleItem24.Text = "Export To..."
        ToolTipItem24.LeftIndent = 6
        ToolTipItem24.Text = "Export the current document in one of the available formats, and save it to the f" &
    "ile on a disk."
        SuperToolTip24.Items.Add(ToolTipTitleItem24)
        SuperToolTip24.Items.Add(ToolTipItem24)
        SuperToolTip24.MaxWidth = 210
        Me.btn_Export.SuperTip = SuperToolTip24
        '
        'btn_Export_Mail
        '
        Me.btn_Export_Mail.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.btn_Export_Mail.Caption = "E-Mail As"
        Me.btn_Export_Mail.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendFile
        Me.btn_Export_Mail.ContextSpecifier = Me.RibbonController
        Me.btn_Export_Mail.Enabled = False
        Me.btn_Export_Mail.Id = 26
        Me.btn_Export_Mail.Name = "btn_Export_Mail"
        SuperToolTip25.FixedTooltipWidth = True
        ToolTipTitleItem25.Text = "E-Mail As..."
        ToolTipItem25.LeftIndent = 6
        ToolTipItem25.Text = "Export the current document in one of the available formats, and attach it to the" &
    " e-mail."
        SuperToolTip25.Items.Add(ToolTipTitleItem25)
        SuperToolTip25.Items.Add(ToolTipItem25)
        SuperToolTip25.MaxWidth = 210
        Me.btn_Export_Mail.SuperTip = SuperToolTip25
        '
        'btn_Close
        '
        Me.btn_Close.Caption = "Close"
        Me.btn_Close.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ClosePreview
        Me.btn_Close.ContextSpecifier = Me.RibbonController
        Me.btn_Close.Enabled = False
        Me.btn_Close.Id = 27
        Me.btn_Close.Name = "btn_Close"
        SuperToolTip26.FixedTooltipWidth = True
        ToolTipTitleItem26.Text = "Close Print Preview"
        ToolTipItem26.LeftIndent = 6
        ToolTipItem26.Text = "Close Print Preview of the document."
        SuperToolTip26.Items.Add(ToolTipTitleItem26)
        SuperToolTip26.Items.Add(ToolTipItem26)
        SuperToolTip26.MaxWidth = 210
        Me.btn_Close.SuperTip = SuperToolTip26
        '
        'btn_PageSetup_Orientation
        '
        Me.btn_PageSetup_Orientation.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.btn_PageSetup_Orientation.Caption = "Orientation"
        Me.btn_PageSetup_Orientation.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageOrientation
        Me.btn_PageSetup_Orientation.ContextSpecifier = Me.RibbonController
        Me.btn_PageSetup_Orientation.Enabled = False
        Me.btn_PageSetup_Orientation.Id = 28
        Me.btn_PageSetup_Orientation.Name = "btn_PageSetup_Orientation"
        SuperToolTip27.FixedTooltipWidth = True
        ToolTipTitleItem27.Text = "Page Orientation"
        ToolTipItem27.LeftIndent = 6
        ToolTipItem27.Text = "Switch the pages between portrait and landscape layouts."
        SuperToolTip27.Items.Add(ToolTipTitleItem27)
        SuperToolTip27.Items.Add(ToolTipItem27)
        SuperToolTip27.MaxWidth = 210
        Me.btn_PageSetup_Orientation.SuperTip = SuperToolTip27
        '
        'btn_PageSetup_Size
        '
        Me.btn_PageSetup_Size.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.btn_PageSetup_Size.Caption = "Size"
        Me.btn_PageSetup_Size.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PaperSize
        Me.btn_PageSetup_Size.ContextSpecifier = Me.RibbonController
        Me.btn_PageSetup_Size.Enabled = False
        Me.btn_PageSetup_Size.Id = 29
        Me.btn_PageSetup_Size.Name = "btn_PageSetup_Size"
        SuperToolTip28.FixedTooltipWidth = True
        ToolTipTitleItem28.Text = "Page Size"
        ToolTipItem28.LeftIndent = 6
        ToolTipItem28.Text = "Choose the paper size of the document."
        SuperToolTip28.Items.Add(ToolTipTitleItem28)
        SuperToolTip28.Items.Add(ToolTipItem28)
        SuperToolTip28.MaxWidth = 210
        Me.btn_PageSetup_Size.SuperTip = SuperToolTip28
        '
        'btn_PageSetup_Margins
        '
        Me.btn_PageSetup_Margins.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.btn_PageSetup_Margins.Caption = "Margins"
        Me.btn_PageSetup_Margins.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageMargins
        Me.btn_PageSetup_Margins.ContextSpecifier = Me.RibbonController
        Me.btn_PageSetup_Margins.Enabled = False
        Me.btn_PageSetup_Margins.Id = 30
        Me.btn_PageSetup_Margins.Name = "btn_PageSetup_Margins"
        SuperToolTip29.FixedTooltipWidth = True
        ToolTipTitleItem29.Text = "Page Margins"
        ToolTipItem29.LeftIndent = 6
        ToolTipItem29.Text = "Select the margin sizes for the entire document." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "To apply specific margin size" &
    "s to the document, click Custom Margins."
        SuperToolTip29.Items.Add(ToolTipTitleItem29)
        SuperToolTip29.Items.Add(ToolTipItem29)
        SuperToolTip29.MaxWidth = 210
        Me.btn_PageSetup_Margins.SuperTip = SuperToolTip29
        '
        'btn_Send_PDF
        '
        Me.btn_Send_PDF.Caption = "PDF File"
        Me.btn_Send_PDF.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendPdf
        Me.btn_Send_PDF.ContextSpecifier = Me.RibbonController
        Me.btn_Send_PDF.Enabled = False
        Me.btn_Send_PDF.Id = 31
        Me.btn_Send_PDF.Name = "btn_Send_PDF"
        SuperToolTip30.FixedTooltipWidth = True
        ToolTipTitleItem30.Text = "E-Mail As PDF"
        ToolTipItem30.LeftIndent = 6
        ToolTipItem30.Text = "Export the document to PDF and attach it to the e-mail."
        SuperToolTip30.Items.Add(ToolTipTitleItem30)
        SuperToolTip30.Items.Add(ToolTipItem30)
        SuperToolTip30.MaxWidth = 210
        Me.btn_Send_PDF.SuperTip = SuperToolTip30
        '
        'btn_Send_Text
        '
        Me.btn_Send_Text.Caption = "Text File"
        Me.btn_Send_Text.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendTxt
        Me.btn_Send_Text.ContextSpecifier = Me.RibbonController
        Me.btn_Send_Text.Enabled = False
        Me.btn_Send_Text.Id = 32
        Me.btn_Send_Text.Name = "btn_Send_Text"
        SuperToolTip31.FixedTooltipWidth = True
        ToolTipTitleItem31.Text = "E-Mail As Text"
        ToolTipItem31.LeftIndent = 6
        ToolTipItem31.Text = "Export the document to Text and attach it to the e-mail."
        SuperToolTip31.Items.Add(ToolTipTitleItem31)
        SuperToolTip31.Items.Add(ToolTipItem31)
        SuperToolTip31.MaxWidth = 210
        Me.btn_Send_Text.SuperTip = SuperToolTip31
        '
        'btn_Send_CSV
        '
        Me.btn_Send_CSV.Caption = "CSV File"
        Me.btn_Send_CSV.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendCsv
        Me.btn_Send_CSV.ContextSpecifier = Me.RibbonController
        Me.btn_Send_CSV.Enabled = False
        Me.btn_Send_CSV.Id = 33
        Me.btn_Send_CSV.Name = "btn_Send_CSV"
        SuperToolTip32.FixedTooltipWidth = True
        ToolTipTitleItem32.Text = "E-Mail As CSV"
        ToolTipItem32.LeftIndent = 6
        ToolTipItem32.Text = "Export the document to CSV and attach it to the e-mail."
        SuperToolTip32.Items.Add(ToolTipTitleItem32)
        SuperToolTip32.Items.Add(ToolTipItem32)
        SuperToolTip32.MaxWidth = 210
        Me.btn_Send_CSV.SuperTip = SuperToolTip32
        '
        'btn_Send_Mht
        '
        Me.btn_Send_Mht.Caption = "MHT File"
        Me.btn_Send_Mht.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendMht
        Me.btn_Send_Mht.ContextSpecifier = Me.RibbonController
        Me.btn_Send_Mht.Enabled = False
        Me.btn_Send_Mht.Id = 34
        Me.btn_Send_Mht.Name = "btn_Send_Mht"
        SuperToolTip33.FixedTooltipWidth = True
        ToolTipTitleItem33.Text = "E-Mail As MHT"
        ToolTipItem33.LeftIndent = 6
        ToolTipItem33.Text = "Export the document to MHT and attach it to the e-mail."
        SuperToolTip33.Items.Add(ToolTipTitleItem33)
        SuperToolTip33.Items.Add(ToolTipItem33)
        SuperToolTip33.MaxWidth = 210
        Me.btn_Send_Mht.SuperTip = SuperToolTip33
        '
        'btn_Send_Xls
        '
        Me.btn_Send_Xls.Caption = "XLS File"
        Me.btn_Send_Xls.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendXls
        Me.btn_Send_Xls.ContextSpecifier = Me.RibbonController
        Me.btn_Send_Xls.Enabled = False
        Me.btn_Send_Xls.Id = 35
        Me.btn_Send_Xls.Name = "btn_Send_Xls"
        SuperToolTip34.FixedTooltipWidth = True
        ToolTipTitleItem34.Text = "E-Mail As XLS"
        ToolTipItem34.LeftIndent = 6
        ToolTipItem34.Text = "Export the document to XLS and attach it to the e-mail."
        SuperToolTip34.Items.Add(ToolTipTitleItem34)
        SuperToolTip34.Items.Add(ToolTipItem34)
        SuperToolTip34.MaxWidth = 210
        Me.btn_Send_Xls.SuperTip = SuperToolTip34
        '
        'btn_Send_Xlsx
        '
        Me.btn_Send_Xlsx.Caption = "XLSX File"
        Me.btn_Send_Xlsx.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendXlsx
        Me.btn_Send_Xlsx.ContextSpecifier = Me.RibbonController
        Me.btn_Send_Xlsx.Enabled = False
        Me.btn_Send_Xlsx.Id = 36
        Me.btn_Send_Xlsx.Name = "btn_Send_Xlsx"
        SuperToolTip35.FixedTooltipWidth = True
        ToolTipTitleItem35.Text = "E-Mail As XLSX"
        ToolTipItem35.LeftIndent = 6
        ToolTipItem35.Text = "Export the document to XLSX and attach it to the e-mail."
        SuperToolTip35.Items.Add(ToolTipTitleItem35)
        SuperToolTip35.Items.Add(ToolTipItem35)
        SuperToolTip35.MaxWidth = 210
        Me.btn_Send_Xlsx.SuperTip = SuperToolTip35
        '
        'btn_Send_RTF
        '
        Me.btn_Send_RTF.Caption = "RTF File"
        Me.btn_Send_RTF.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendRtf
        Me.btn_Send_RTF.ContextSpecifier = Me.RibbonController
        Me.btn_Send_RTF.Enabled = False
        Me.btn_Send_RTF.Id = 37
        Me.btn_Send_RTF.Name = "btn_Send_RTF"
        SuperToolTip36.FixedTooltipWidth = True
        ToolTipTitleItem36.Text = "E-Mail As RTF"
        ToolTipItem36.LeftIndent = 6
        ToolTipItem36.Text = "Export the document to RTF and attach it to the e-mail."
        SuperToolTip36.Items.Add(ToolTipTitleItem36)
        SuperToolTip36.Items.Add(ToolTipItem36)
        SuperToolTip36.MaxWidth = 210
        Me.btn_Send_RTF.SuperTip = SuperToolTip36
        '
        'btn_Send_Docx
        '
        Me.btn_Send_Docx.Caption = "DOCX File"
        Me.btn_Send_Docx.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendDocx
        Me.btn_Send_Docx.ContextSpecifier = Me.RibbonController
        Me.btn_Send_Docx.Enabled = False
        Me.btn_Send_Docx.Id = 38
        Me.btn_Send_Docx.Name = "btn_Send_Docx"
        SuperToolTip37.FixedTooltipWidth = True
        ToolTipTitleItem37.Text = "E-Mail As DOCX"
        ToolTipItem37.LeftIndent = 6
        ToolTipItem37.Text = "Export the document to DOCX and attach it to the e-mail."
        SuperToolTip37.Items.Add(ToolTipTitleItem37)
        SuperToolTip37.Items.Add(ToolTipItem37)
        SuperToolTip37.MaxWidth = 210
        Me.btn_Send_Docx.SuperTip = SuperToolTip37
        '
        'btn_Send_Image
        '
        Me.btn_Send_Image.Caption = "Image File"
        Me.btn_Send_Image.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendGraphic
        Me.btn_Send_Image.ContextSpecifier = Me.RibbonController
        Me.btn_Send_Image.Enabled = False
        Me.btn_Send_Image.Id = 39
        Me.btn_Send_Image.Name = "btn_Send_Image"
        SuperToolTip38.FixedTooltipWidth = True
        ToolTipTitleItem38.Text = "E-Mail As Image"
        ToolTipItem38.LeftIndent = 6
        ToolTipItem38.Text = "Export the document to Image and attach it to the e-mail."
        SuperToolTip38.Items.Add(ToolTipTitleItem38)
        SuperToolTip38.Items.Add(ToolTipItem38)
        SuperToolTip38.MaxWidth = 210
        Me.btn_Send_Image.SuperTip = SuperToolTip38
        '
        'btn_Export_PDF
        '
        Me.btn_Export_PDF.Caption = "PDF File"
        Me.btn_Export_PDF.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportPdf
        Me.btn_Export_PDF.ContextSpecifier = Me.RibbonController
        Me.btn_Export_PDF.Enabled = False
        Me.btn_Export_PDF.Id = 40
        Me.btn_Export_PDF.Name = "btn_Export_PDF"
        SuperToolTip39.FixedTooltipWidth = True
        ToolTipTitleItem39.Text = "Export to PDF"
        ToolTipItem39.LeftIndent = 6
        ToolTipItem39.Text = "Export the document to PDF and save it to the file on a disk."
        SuperToolTip39.Items.Add(ToolTipTitleItem39)
        SuperToolTip39.Items.Add(ToolTipItem39)
        SuperToolTip39.MaxWidth = 210
        Me.btn_Export_PDF.SuperTip = SuperToolTip39
        '
        'btn_Export_HTML
        '
        Me.btn_Export_HTML.Caption = "HTML File"
        Me.btn_Export_HTML.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportHtm
        Me.btn_Export_HTML.ContextSpecifier = Me.RibbonController
        Me.btn_Export_HTML.Enabled = False
        Me.btn_Export_HTML.Id = 41
        Me.btn_Export_HTML.Name = "btn_Export_HTML"
        SuperToolTip40.FixedTooltipWidth = True
        ToolTipTitleItem40.Text = "Export to HTML"
        ToolTipItem40.LeftIndent = 6
        ToolTipItem40.Text = "Export the document to HTML and save it to the file on a disk."
        SuperToolTip40.Items.Add(ToolTipTitleItem40)
        SuperToolTip40.Items.Add(ToolTipItem40)
        SuperToolTip40.MaxWidth = 210
        Me.btn_Export_HTML.SuperTip = SuperToolTip40
        '
        'btn_Export_Text
        '
        Me.btn_Export_Text.Caption = "Text File"
        Me.btn_Export_Text.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportTxt
        Me.btn_Export_Text.ContextSpecifier = Me.RibbonController
        Me.btn_Export_Text.Enabled = False
        Me.btn_Export_Text.Id = 42
        Me.btn_Export_Text.Name = "btn_Export_Text"
        SuperToolTip41.FixedTooltipWidth = True
        ToolTipTitleItem41.Text = "Export to Text"
        ToolTipItem41.LeftIndent = 6
        ToolTipItem41.Text = "Export the document to Text and save it to the file on a disk."
        SuperToolTip41.Items.Add(ToolTipTitleItem41)
        SuperToolTip41.Items.Add(ToolTipItem41)
        SuperToolTip41.MaxWidth = 210
        Me.btn_Export_Text.SuperTip = SuperToolTip41
        '
        'btn_Export_CSV
        '
        Me.btn_Export_CSV.Caption = "CSV File"
        Me.btn_Export_CSV.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportCsv
        Me.btn_Export_CSV.ContextSpecifier = Me.RibbonController
        Me.btn_Export_CSV.Enabled = False
        Me.btn_Export_CSV.Id = 43
        Me.btn_Export_CSV.Name = "btn_Export_CSV"
        SuperToolTip42.FixedTooltipWidth = True
        ToolTipTitleItem42.Text = "Export to CSV"
        ToolTipItem42.LeftIndent = 6
        ToolTipItem42.Text = "Export the document to CSV and save it to the file on a disk."
        SuperToolTip42.Items.Add(ToolTipTitleItem42)
        SuperToolTip42.Items.Add(ToolTipItem42)
        SuperToolTip42.MaxWidth = 210
        Me.btn_Export_CSV.SuperTip = SuperToolTip42
        '
        'btn_Export_Mht
        '
        Me.btn_Export_Mht.Caption = "MHT File"
        Me.btn_Export_Mht.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportMht
        Me.btn_Export_Mht.ContextSpecifier = Me.RibbonController
        Me.btn_Export_Mht.Enabled = False
        Me.btn_Export_Mht.Id = 44
        Me.btn_Export_Mht.Name = "btn_Export_Mht"
        SuperToolTip43.FixedTooltipWidth = True
        ToolTipTitleItem43.Text = "Export to MHT"
        ToolTipItem43.LeftIndent = 6
        ToolTipItem43.Text = "Export the document to MHT and save it to the file on a disk."
        SuperToolTip43.Items.Add(ToolTipTitleItem43)
        SuperToolTip43.Items.Add(ToolTipItem43)
        SuperToolTip43.MaxWidth = 210
        Me.btn_Export_Mht.SuperTip = SuperToolTip43
        '
        'btn_Export_Xls
        '
        Me.btn_Export_Xls.Caption = "XLS File"
        Me.btn_Export_Xls.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportXls
        Me.btn_Export_Xls.ContextSpecifier = Me.RibbonController
        Me.btn_Export_Xls.Enabled = False
        Me.btn_Export_Xls.Id = 45
        Me.btn_Export_Xls.Name = "btn_Export_Xls"
        SuperToolTip44.FixedTooltipWidth = True
        ToolTipTitleItem44.Text = "Export to XLS"
        ToolTipItem44.LeftIndent = 6
        ToolTipItem44.Text = "Export the document to XLS and save it to the file on a disk."
        SuperToolTip44.Items.Add(ToolTipTitleItem44)
        SuperToolTip44.Items.Add(ToolTipItem44)
        SuperToolTip44.MaxWidth = 210
        Me.btn_Export_Xls.SuperTip = SuperToolTip44
        '
        'btn_Export_Xlsx
        '
        Me.btn_Export_Xlsx.Caption = "XLSX File"
        Me.btn_Export_Xlsx.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportXlsx
        Me.btn_Export_Xlsx.ContextSpecifier = Me.RibbonController
        Me.btn_Export_Xlsx.Enabled = False
        Me.btn_Export_Xlsx.Id = 46
        Me.btn_Export_Xlsx.Name = "btn_Export_Xlsx"
        SuperToolTip45.FixedTooltipWidth = True
        ToolTipTitleItem45.Text = "Export to XLSX"
        ToolTipItem45.LeftIndent = 6
        ToolTipItem45.Text = "Export the document to XLSX and save it to the file on a disk."
        SuperToolTip45.Items.Add(ToolTipTitleItem45)
        SuperToolTip45.Items.Add(ToolTipItem45)
        SuperToolTip45.MaxWidth = 210
        Me.btn_Export_Xlsx.SuperTip = SuperToolTip45
        '
        'btn_Export_RTF
        '
        Me.btn_Export_RTF.Caption = "RTF File"
        Me.btn_Export_RTF.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportRtf
        Me.btn_Export_RTF.ContextSpecifier = Me.RibbonController
        Me.btn_Export_RTF.Enabled = False
        Me.btn_Export_RTF.Id = 47
        Me.btn_Export_RTF.Name = "btn_Export_RTF"
        SuperToolTip46.FixedTooltipWidth = True
        ToolTipTitleItem46.Text = "Export to RTF"
        ToolTipItem46.LeftIndent = 6
        ToolTipItem46.Text = "Export the document to RTF and save it to the file on a disk."
        SuperToolTip46.Items.Add(ToolTipTitleItem46)
        SuperToolTip46.Items.Add(ToolTipItem46)
        SuperToolTip46.MaxWidth = 210
        Me.btn_Export_RTF.SuperTip = SuperToolTip46
        '
        'btn_Export_Docx
        '
        Me.btn_Export_Docx.Caption = "DOCX File"
        Me.btn_Export_Docx.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportDocx
        Me.btn_Export_Docx.ContextSpecifier = Me.RibbonController
        Me.btn_Export_Docx.Enabled = False
        Me.btn_Export_Docx.Id = 48
        Me.btn_Export_Docx.Name = "btn_Export_Docx"
        SuperToolTip47.FixedTooltipWidth = True
        ToolTipTitleItem47.Text = "Export to DOCX"
        ToolTipItem47.LeftIndent = 6
        ToolTipItem47.Text = "Export the document to DOCX and save it to the file on a disk."
        SuperToolTip47.Items.Add(ToolTipTitleItem47)
        SuperToolTip47.Items.Add(ToolTipItem47)
        SuperToolTip47.MaxWidth = 210
        Me.btn_Export_Docx.SuperTip = SuperToolTip47
        '
        'btn_Export_Image
        '
        Me.btn_Export_Image.Caption = "Image File"
        Me.btn_Export_Image.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportGraphic
        Me.btn_Export_Image.ContextSpecifier = Me.RibbonController
        Me.btn_Export_Image.Enabled = False
        Me.btn_Export_Image.Id = 49
        Me.btn_Export_Image.Name = "btn_Export_Image"
        SuperToolTip48.FixedTooltipWidth = True
        ToolTipTitleItem48.Text = "Export to Image"
        ToolTipItem48.LeftIndent = 6
        ToolTipItem48.Text = "Export the document to Image and save it to the file on a disk."
        SuperToolTip48.Items.Add(ToolTipTitleItem48)
        SuperToolTip48.Items.Add(ToolTipItem48)
        SuperToolTip48.MaxWidth = 210
        Me.btn_Export_Image.SuperTip = SuperToolTip48
        '
        'txt_Status
        '
        Me.txt_Status.Caption = "Nothing"
        Me.txt_Status.Id = 52
        Me.txt_Status.LeftIndent = 1
        Me.txt_Status.Name = "txt_Status"
        Me.txt_Status.RightIndent = 1
        Me.txt_Status.Type = "PageOfPages"
        '
        'BarStaticItem1
        '
        Me.BarStaticItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left
        Me.BarStaticItem1.Enabled = False
        Me.BarStaticItem1.Id = 53
        Me.BarStaticItem1.Name = "BarStaticItem1"
        Me.BarStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInRuntime
        '
        'progress_Status
        '
        Me.progress_Status.ContextSpecifier = Me.RibbonController
        Me.progress_Status.Edit = Me.progress_Status_Item
        Me.progress_Status.EditHeight = 12
        Me.progress_Status.EditWidth = 150
        Me.progress_Status.Id = 54
        Me.progress_Status.Name = "progress_Status"
        Me.progress_Status.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
        '
        'progress_Status_Item
        '
        Me.progress_Status_Item.Name = "progress_Status_Item"
        '
        'btn_Stop
        '
        Me.btn_Stop.Caption = "Stop"
        Me.btn_Stop.Command = DevExpress.XtraPrinting.PrintingSystemCommand.StopPageBuilding
        Me.btn_Stop.ContextSpecifier = Me.RibbonController
        Me.btn_Stop.Enabled = False
        Me.btn_Stop.Hint = "Stop"
        Me.btn_Stop.Id = 55
        Me.btn_Stop.Name = "btn_Stop"
        Me.btn_Stop.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
        '
        'txt_Zoom
        '
        Me.txt_Zoom.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
        Me.txt_Zoom.AutoSize = DevExpress.XtraBars.BarStaticItemSize.None
        Me.txt_Zoom.Caption = "100%"
        Me.txt_Zoom.Id = 56
        Me.txt_Zoom.Name = "txt_Zoom"
        Me.txt_Zoom.Type = "ZoomFactorText"
        '
        'track_Zoom
        '
        Me.track_Zoom.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
        Me.track_Zoom.ContextSpecifier = Me.RibbonController
        Me.track_Zoom.Edit = Me.track_Zoom_Item
        Me.track_Zoom.EditValue = 90
        Me.track_Zoom.EditWidth = 140
        Me.track_Zoom.Enabled = False
        Me.track_Zoom.Id = 57
        Me.track_Zoom.Name = "track_Zoom"
        Me.track_Zoom.Range = New Integer() {10, 500}
        '
        'track_Zoom_Item
        '
        Me.track_Zoom_Item.Alignment = DevExpress.Utils.VertAlignment.Center
        Me.track_Zoom_Item.AllowFocused = False
        Me.track_Zoom_Item.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.track_Zoom_Item.Maximum = 180
        Me.track_Zoom_Item.Name = "track_Zoom_Item"
        '
        'rp_PrintPreview
        '
        Me.rp_PrintPreview.ContextSpecifier = Me.RibbonController
        Me.rp_PrintPreview.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.rpg_Print, Me.rpg_Navigation, Me.rpg_Zoom, Me.rpg_Export, Me.rpg_Close})
        Me.rp_PrintPreview.Name = "rp_PrintPreview"
        Me.rp_PrintPreview.Text = "Print Preview"
        '
        'rpg_Print
        '
        Me.rpg_Print.AllowTextClipping = False
        Me.rpg_Print.ContextSpecifier = Me.RibbonController
        Me.rpg_Print.ItemLinks.Add(Me.btn_Print)
        Me.rpg_Print.ItemLinks.Add(Me.btn_QuickPrint)
        Me.rpg_Print.ItemLinks.Add(Me.btn_Print_Options)
        Me.rpg_Print.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Print
        Me.rpg_Print.Name = "rpg_Print"
        Me.rpg_Print.ShowCaptionButton = False
        Me.rpg_Print.Text = "Print"
        '
        'rpg_Navigation
        '
        Me.rpg_Navigation.AllowTextClipping = False
        Me.rpg_Navigation.ContextSpecifier = Me.RibbonController
        Me.rpg_Navigation.ItemLinks.Add(Me.btn_Navigation_Find)
        Me.rpg_Navigation.ItemLinks.Add(Me.btn_Navigation_Thumbnails)
        Me.rpg_Navigation.ItemLinks.Add(Me.btn_Navigation_Bookmarks)
        Me.rpg_Navigation.ItemLinks.Add(Me.btn_Navigation_EditingFields)
        Me.rpg_Navigation.ItemLinks.Add(Me.btn_Navigation_First, True)
        Me.rpg_Navigation.ItemLinks.Add(Me.btn_Navigation_Last)
        Me.rpg_Navigation.ItemLinks.Add(Me.btn_Navigation_Previous)
        Me.rpg_Navigation.ItemLinks.Add(Me.btn_Navigation_Next)
        Me.rpg_Navigation.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Navigation
        Me.rpg_Navigation.Name = "rpg_Navigation"
        Me.rpg_Navigation.ShowCaptionButton = False
        Me.rpg_Navigation.Text = "Navigation"
        '
        'rpg_Zoom
        '
        Me.rpg_Zoom.AllowTextClipping = False
        Me.rpg_Zoom.ContextSpecifier = Me.RibbonController
        Me.rpg_Zoom.ItemLinks.Add(Me.btn_Zoom_Out, True)
        Me.rpg_Zoom.ItemLinks.Add(Me.btn_Zoom_In)
        Me.rpg_Zoom.ItemLinks.Add(Me.btn_Zoom_Zoom)
        Me.rpg_Zoom.ItemLinks.Add(Me.btn_Zoom_MultiplePages)
        Me.rpg_Zoom.ItemLinks.Add(Me.btn_Zoom_Pointer, True)
        Me.rpg_Zoom.ItemLinks.Add(Me.btn_Zoom_Hand)
        Me.rpg_Zoom.ItemLinks.Add(Me.btn_Zoom_MagGlass)
        Me.rpg_Zoom.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Zoom
        Me.rpg_Zoom.Name = "rpg_Zoom"
        Me.rpg_Zoom.ShowCaptionButton = False
        Me.rpg_Zoom.Text = "Zoom"
        '
        'rpg_Export
        '
        Me.rpg_Export.AllowTextClipping = False
        Me.rpg_Export.ContextSpecifier = Me.RibbonController
        Me.rpg_Export.ItemLinks.Add(Me.btn_Export)
        Me.rpg_Export.ItemLinks.Add(Me.btn_Export_Mail)
        Me.rpg_Export.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Export
        Me.rpg_Export.Name = "rpg_Export"
        Me.rpg_Export.ShowCaptionButton = False
        Me.rpg_Export.Text = "Export"
        '
        'rpg_Close
        '
        Me.rpg_Close.AllowTextClipping = False
        Me.rpg_Close.ContextSpecifier = Me.RibbonController
        Me.rpg_Close.ItemLinks.Add(Me.btn_Close)
        Me.rpg_Close.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Close
        Me.rpg_Close.Name = "rpg_Close"
        Me.rpg_Close.ShowCaptionButton = False
        Me.rpg_Close.Text = "Close"
        '
        'rp_PageSetup
        '
        Me.rp_PageSetup.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.rpg_PageSetup})
        Me.rp_PageSetup.Name = "rp_PageSetup"
        Me.rp_PageSetup.Text = "Page Setup"
        '
        'rpg_PageSetup
        '
        Me.rpg_PageSetup.AllowTextClipping = False
        Me.rpg_PageSetup.ContextSpecifier = Me.RibbonController
        Me.rpg_PageSetup.ItemLinks.Add(Me.btn_PageSetup_HeaderFooter)
        Me.rpg_PageSetup.ItemLinks.Add(Me.btn_PageSetup_Size)
        Me.rpg_PageSetup.ItemLinks.Add(Me.btn_PageSetup_Margins)
        Me.rpg_PageSetup.ItemLinks.Add(Me.btn_PageSetup_Orientation)
        Me.rpg_PageSetup.ItemLinks.Add(Me.btn_PageSetup_Scale)
        Me.rpg_PageSetup.ItemLinks.Add(Me.btn_PageSetup_PageColor)
        Me.rpg_PageSetup.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.PageSetup
        Me.rpg_PageSetup.Name = "rpg_PageSetup"
        SuperToolTip49.FixedTooltipWidth = True
        ToolTipTitleItem49.Text = "Page Setup"
        ToolTipItem49.LeftIndent = 6
        ToolTipItem49.Text = "Show the Page Setup dialog."
        SuperToolTip49.Items.Add(ToolTipTitleItem49)
        SuperToolTip49.Items.Add(ToolTipItem49)
        SuperToolTip49.MaxWidth = 210
        Me.rpg_PageSetup.SuperTip = SuperToolTip49
        Me.rpg_PageSetup.Text = "Page Setup"
        '
        'RibbonStatusBar
        '
        Me.RibbonStatusBar.ItemLinks.Add(Me.txt_Status)
        Me.RibbonStatusBar.ItemLinks.Add(Me.BarStaticItem1)
        Me.RibbonStatusBar.ItemLinks.Add(Me.progress_Status)
        Me.RibbonStatusBar.ItemLinks.Add(Me.btn_Stop)
        Me.RibbonStatusBar.ItemLinks.Add(Me.txt_Zoom)
        Me.RibbonStatusBar.ItemLinks.Add(Me.track_Zoom)
        Me.RibbonStatusBar.Location = New System.Drawing.Point(0, 419)
        Me.RibbonStatusBar.Name = "RibbonStatusBar"
        Me.RibbonStatusBar.Ribbon = Me.RibbonControl
        Me.RibbonStatusBar.Size = New System.Drawing.Size(758, 31)
        '
        'frm_ReportViewer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(758, 450)
        Me.Controls.Add(Me.DocumentViewer)
        Me.Controls.Add(Me.RibbonStatusBar)
        Me.Controls.Add(Me.RibbonControl)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_ReportViewer"
        Me.Ribbon = Me.RibbonControl
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.StatusBar = Me.RibbonStatusBar
        Me.Text = "Report Viewer"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.RibbonController, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RibbonControl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.progress_Status_Item, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.track_Zoom_Item, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DocumentViewer As DevExpress.XtraPrinting.Preview.DocumentViewer
        Friend WithEvents RibbonController As DevExpress.XtraPrinting.Preview.DocumentViewerRibbonController
        Friend WithEvents RibbonControl As DevExpress.XtraBars.Ribbon.RibbonControl
        Friend WithEvents btn_Navigation_EditingFields As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Navigation_Bookmarks As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Navigation_Find As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Navigation_Thumbnails As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Print_Options As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Print As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_QuickPrint As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_PageSetup_Margins_Custom As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_PageSetup_HeaderFooter As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_PageSetup_Scale As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Zoom_Pointer As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Zoom_Hand As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Zoom_MagGlass As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Zoom_Out As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Zoom_In As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Zoom_Zoom As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Navigation_First As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Navigation_Previous As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Navigation_Next As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Navigation_Last As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Zoom_MultiplePages As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_PageSetup_PageColor As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_PageSetup_Watermark As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_Mail As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Close As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_PageSetup_Orientation As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_PageSetup_Size As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_PageSetup_Margins As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Send_PDF As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Send_Text As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Send_CSV As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Send_Mht As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Send_Xls As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Send_Xlsx As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Send_RTF As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Send_Docx As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Send_Image As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_PDF As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_HTML As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_Text As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_CSV As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_Mht As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_Xls As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_Xlsx As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_RTF As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_Docx As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents btn_Export_Image As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents txt_Status As DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem
        Friend WithEvents BarStaticItem1 As DevExpress.XtraBars.BarStaticItem
        Friend WithEvents progress_Status As DevExpress.XtraPrinting.Preview.ProgressBarEditItem
        Friend WithEvents progress_Status_Item As DevExpress.XtraEditors.Repository.RepositoryItemProgressBar
        Friend WithEvents btn_Stop As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
        Friend WithEvents txt_Zoom As DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem
        Friend WithEvents track_Zoom As DevExpress.XtraPrinting.Preview.ZoomTrackBarEditItem
        Friend WithEvents track_Zoom_Item As DevExpress.XtraEditors.Repository.RepositoryItemZoomTrackBar
        Friend WithEvents rp_PrintPreview As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPage
        Friend WithEvents rpg_Print As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
        Friend WithEvents rpg_PageSetup As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
        Friend WithEvents rpg_Navigation As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
        Friend WithEvents rpg_Zoom As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
        Friend WithEvents rpg_Export As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
        Friend WithEvents rpg_Close As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
        Friend WithEvents RibbonStatusBar As DevExpress.XtraBars.Ribbon.RibbonStatusBar
        Friend WithEvents rp_PageSetup As DevExpress.XtraBars.Ribbon.RibbonPage
End Class